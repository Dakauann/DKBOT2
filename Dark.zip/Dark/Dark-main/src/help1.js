const help1 = (prefix) => {

	return `
╭──────────────╮
 𝐃𝐤𝐎𝐅𝐂-𝐁𝐎𝐓😎🤙*
╰──────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}loli*
➸ *${prefix}loli1*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}meme*
➸ *${prefix}lofi*
➸ *${prefix}malkova*
➸ *${prefix}canal*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}marcar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*𝐃𝐤𝐎𝐅𝐂-𝐁𝐎𝐓
════════════════════`

}
exports.help1 = help1


